---
name: font-spacing-kerning
description: Establish base sidebearings, word separation, and kerning exceptions; review spacing proposals and justify optical judgments with compiled evidence. Use after core proportions are stable, including punctuation and substituted-glyph boundaries; route shape changes to outline or ligature design.
---

# Font Spacing and Kerning

Make base spacing coherent before pair exceptions. Read the current project revision and UPM; canvas width is not advance width. Judge actual compiled images, not equal numbers or collision-free bounds.

## Establish base rhythm and word boundaries

Start with `H O` for capitals and `n o` for lowercase. Render repeated/interleaved controls with kerning disabled; use the [test corpus](../font-specimen-review/references/test-corpus.md) for starting strings. Flat, round, diagonal, and open forms need related perceived texture, not identical bearings. Preserve intentional asymmetry.

When a gap follows one glyph across many neighbors, fix its bearings or construction before adding exceptions. Compare internal gaps with **word spaces** in real sentences: readers should distinguish words immediately without turning every space into a hole. If the whole design is widely spaced, a numerically ordinary space may be insufficient.

Capture a baseline before `suggest_spacing`. Inspect each proposed delta and its target separation; apply only through `apply_spacing_proposal` against the unchanged base revision. Font Maker cannot render an unapplied proposal: compare its compiled result after application, or test alternatives on a disposable project. Use `set_glyph_metrics` for deliberate departures from the heuristic. Reopen conflicts; never replay stale changes blindly.

## Test exceptions skeptically

Examples include `AV AW AY`, `To Ta Te Ty`, `Va Vo Ya Yo`, and open lowercase `ra re ro ry rv`. This is **not exhaustive** or a whitelist. Scan arbitrary words, symbols, and repeated letters for unnatural gaps, collisions, or rhythm breaks.

Treat every tested pair as unproven until visually inspected in isolation and context. Start assuming issues remain, but do not invent defects to satisfy that assumption. Before clearing a pair, explain its white-space shape and apparent area, closest outline approach, and relationship to neighboring gaps. “No collision,” “equal bearings,” and “looks fine” are insufficient by themselves. Uncertain cases stay unresolved.

Verify that the specimen contains the **exact case-sensitive sequence**: `Typography` contains `Ty`; `rare` contains `ra`; `more` does not contain `ro`. Pair coverage and actual substitution must be checked, not inferred from a plausible word.

Use groups only for genuinely equivalent relevant sides. Check accented and punctuation members before accepting a class value, and add exceptions for different geometry. Compare kerning off/on while holding other features fixed, at reading and display sizes and inside words. Numeric advance changes reproduce the result but do not decide which looks better.

## Separate spacing, visual weight, and drawing

Open forms such as `r` can leave a large lower cavity while their shoulders are already close. Compare `rare rara parallel` and contexts containing `re ro ar`. Tightening further may pinch the shoulder before balancing the cavity; consider outline refinement or a coordinated replacement instead.

Review punctuation attachment **and weight**. Compare colon/semicolon dots with period, comma, and the `i` dot in real text. Oversized marks or off-center forms cannot be repaired merely by squeezing bearings. Explain their apparent weight, placement, and white space relative to the line; route construction issues to [outline QA](../font-outline-qa/SKILL.md) and [specimen review](../font-specimen-review/SKILL.md).

Creative joins may be worth exploring even when spacing is acceptable; record opportunities separately from defects. Use [ligature design](../font-ligature-design/SKILL.md) for original shared drawings. Never derive repairs from existing fonts. AI concepts can suggest rhythm but cannot supply reliable numeric kerning or unchanged control shapes.

Extreme kerning that changes perceived identity—for example `nn` reading as `m`—requires a concrete comparison and approval unless full creative freedom was explicitly granted. Keep unapproved fusions out of the active font. Routine recognizable corrections need no extra consultation.

## Generate and inspect repeatable proofs

Use the bundled [proof script](scripts/render_kerning_proofs.py) following its [usage and feature contract](references/proof-script.md). It produces labeled OFF/ON sheets, a compiled-font snapshot, hashes, shaping traces, and **pending** review entries. Extend default samples with actual high-risk pairs and words. Missing-glyph skips are incomplete coverage, not passes.

Keep SVGs and use PNG `pixel_scale=3` for spacing diagnosis, `4` for join detail, plus separate `1` previews at actual small reading size. Record `font_size` and scale. Split large sheets; upscaling a low-resolution bitmap adds no evidence. Open the actual images before making judgments.

The script fixes `dlig` off and `rlig` on; it does not certify discretionary ligatures. Use `preview_font` and `shape_text` with explicit features to check replacement boundaries, holding the replacement enabled while toggling kerning. Internal ligature spacing belongs to its drawing/advance, not boundary kerning.

Record image, project revision, font-byte hash, text, feature map, sizes, observation, reason for acceptance, and unresolved action. Distinguish generated, inspected, accepted, and unresolved evidence; state the tested scope without clearing untested combinations.
